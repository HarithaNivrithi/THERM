import test from 'node:test';
import assert from 'node:assert/strict';
import { DEVICES, DEFAULT_CONFIG, temperatureAt, simulate, schedule, crossingTime, replayTemperature, trajectoryData } from './simulation.mjs';

const close = (a, b, tolerance = 1e-9) => assert.ok(Math.abs(a - b) < tolerance, `${a} != ${b}`);

test('RC response starts at T0, converges to Ta + PR, and obeys its closed form', () => {
  close(temperatureAt(0, 25, 46, 5, 3, 20), 46);
  close(temperatureAt(6000, 25, 46, 5, 3, 20), 40);
  const t = 15, decay = Math.exp(-t / 60);
  close(temperatureAt(t, 25, 46, 5, 3, 20), 25 + 21 * decay + 15 * (1 - decay));
});

test('cooling and heating obey PR versus initial elevation; the peak includes T0', () => {
  assert.ok(temperatureAt(20, 25, 46, 5, 3, 20) < 46);
  assert.ok(temperatureAt(20, 25, 30, 5, 3, 20) > 30);
  for (const d of simulate(DEFAULT_CONFIG)) {
    close(d.peak, Math.max(DEFAULT_CONFIG.initial, d.final));
    close(d.energy, d.power * d.duration);
    assert.equal(d.final > d.initial, d.equilibrium > d.initial);
  }
});

test('thermal crossing is analytical and never reported outside the active interval', () => {
  const at = crossingTime(30, 90, 75, 60);
  close(temperatureAt(at, 25, 30, 65 / 3, 3, 20), 75);
  assert.equal(crossingTime(80, 90, 75, 60), 0);
  assert.equal(crossingTime(30, 70, 75, 60), Infinity);
  for (const d of simulate({ ...DEFAULT_CONFIG, ambient: 50, initial: 60, threshold: 65, holdSeconds: 180 })) {
    assert.equal(d.throttleAt !== null, d.peak >= 65);
    if (d.throttleAt !== null) assert.ok(d.throttleAt <= d.duration);
  }
});

test('scheduler selects minimum eligible weighted cost and refuses unsafe dispatch', () => {
  const results = simulate(DEFAULT_CONFIG);
  const decision = schedule(results, DEFAULT_CONFIG);
  assert.ok(decision.selected?.eligible);
  close(decision.selected.score, Math.min(...decision.ranked.filter(d => d.eligible).map(d => d.score)));
  const hot = { ...DEFAULT_CONFIG, initial: 90, threshold: 75 };
  assert.equal(schedule(simulate(hot), hot).selected, null);
  const tight = { ...DEFAULT_CONFIG, deadline: .001 };
  assert.equal(schedule(simulate(tight), tight).selected, null);
  const off = { ...DEFAULT_CONFIG, disabled: DEVICES.map(d => d.id) };
  assert.equal(schedule(simulate(off), off).selected, null);
});

test('static sparsity reduces duration; sustained execution and plant overrides work', () => {
  const dense = simulate({ ...DEFAULT_CONFIG, sparsity: 0 });
  const sparse = simulate({ ...DEFAULT_CONFIG, sparsity: .8 });
  sparse.forEach((d, i) => assert.ok(d.duration < dense[i].duration));
  const sustained = simulate({ ...DEFAULT_CONFIG, holdSeconds: 180 });
  sustained.forEach(d => assert.ok(d.duration >= 180));
  const changed = simulate({ ...DEFAULT_CONFIG, overrides: { dsp: { r: 6, c: 10, powerScale: 1.5 } } }).find(d => d.id === 'dsp');
  const old = simulate(DEFAULT_CONFIG).find(d => d.id === 'dsp');
  close(changed.tau, 60);
  close(changed.power, old.power * 1.5);
});

test('counterfactual curves are continuous at completion and cool toward idle equilibrium', () => {
  for (const d of simulate(DEFAULT_CONFIG)) {
    close(replayTemperature(d, d.duration), d.final);
    close(replayTemperature(d, d.duration + 1e-8), d.final, 1e-7);
    close(replayTemperature(d, d.duration + 1e5), d.ambient + d.idlePower * d.r);
  }
  const curves = trajectoryData(simulate(DEFAULT_CONFIG));
  assert.ok(curves.length >= 101);
  for (const d of simulate(DEFAULT_CONFIG)) assert.ok(curves.some(row => row.time === d.duration));
  for (const row of curves) for (const d of DEVICES) assert.ok(Number.isFinite(row[d.id]));
});

test('chart includes exact completion peaks and threshold-crossing events', () => {
  const config = { ...DEFAULT_CONFIG, ambient: 35, initial: 35, complexity: 100, sparsity: .95, threshold: 48,
    overrides: { cpu: { throughput: 20 }, mobile_cpu: { throughput: 20 }, gpu: { throughput: 380, r: 1, c: 8, powerScale: 2 } } };
  const results = simulate(config), curves = trajectoryData(results);
  const gpu = results.find(d => d.id === 'gpu');
  assert.ok(gpu.peak > config.threshold);
  close(Math.max(...curves.map(row => row.gpu)), gpu.peak);
  const crossing = curves.find(row => row.time === gpu.throttleAt);
  assert.ok(crossing);
  close(crossing.gpu, config.threshold);
});

test('edge scenarios stay finite and constrained across all policies', () => {
  for (const ambient of [10, 50]) for (const initial of [20, 95]) for (const complexity of [0, 100]) for (const policy of ['adaptive', 'latency', 'energy', 'thermal']) {
    const config = { ...DEFAULT_CONFIG, ambient, initial, complexity, policy };
    const results = simulate(config), decision = schedule(results, config);
    for (const d of results) assert.ok([d.duration, d.power, d.energy, d.final, d.peak].every(Number.isFinite));
    if (decision.selected) assert.ok(decision.selected.thermalSafe && decision.selected.deadlineSafe && decision.selected.enabled);
  }
});
