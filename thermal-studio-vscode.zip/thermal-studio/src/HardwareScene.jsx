import React, { Component, Suspense, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Environment, Html, Lightformer, OrbitControls, RoundedBox, useCursor } from '@react-three/drei'
import * as THREE from 'three'

// An illustrative heterogeneous carrier, not a physical Raspberry Pi layout.
const DEVICES = [
  { id: 'cpu', label: 'CPU', position: [-0.87, 0, 0.18], size: [1.48, 1.43], height: 0.28, lift: 0.86 },
  { id: 'gpu', label: 'GPU', position: [1.02, 0, 0.55], size: [1.48, 1.32], height: 0.48, lift: 1.05 },
  { id: 'npu', label: 'NPU', position: [-0.84, 0, -1.24], size: [1.16, 0.88], height: 0.29, lift: 0.76 },
  { id: 'dsp', label: 'DSP', position: [1.53, 0, -1.25], size: [0.87, 0.78], height: 0.23, lift: 0.68 },
  { id: 'mobile_cpu', label: 'M-CPU', position: [-2.25, 0, 0.78], size: [0.91, 0.99], height: 0.27, lift: 0.94 },
]
const TOP = 0.18
const GOLD = '#edb84c'
const ICE = '#c3cbd5'
const HoverContext = React.createContext(() => {})
const clamp = THREE.MathUtils.clamp
const damp = (value, target, delta, speed = 8) => THREE.MathUtils.damp(value, target, speed, Math.min(delta, 0.1))
const temperatureFor = (temperatures, id) => {
  const value = temperatures?.[id]
  return typeof value === 'number' && Number.isFinite(value) ? value : 38
}
const THERMAL_STOPS = [[32, '#a9bbc8'], [53, '#e5c473'], [70, '#ee943e'], [87, '#e75631'], [103, '#c5354a']]
function thermalColor(temperature) {
  const value = clamp(temperature, THERMAL_STOPS[0][0], THERMAL_STOPS.at(-1)[0])
  for (let i = 1; i < THERMAL_STOPS.length; i += 1) {
    if (value <= THERMAL_STOPS[i][0]) {
      const [low, a] = THERMAL_STOPS[i - 1]
      const [high, b] = THERMAL_STOPS[i]
      return new THREE.Color(a).lerp(new THREE.Color(b), (value - low) / (high - low))
    }
  }
  return new THREE.Color(THERMAL_STOPS.at(-1)[1])
}

function roundedPath(path, width, depth, radius) {
  const x = -width / 2
  const y = -depth / 2
  path.moveTo(x + radius, y)
  path.lineTo(x + width - radius, y)
  path.quadraticCurveTo(x + width, y, x + width, y + radius)
  path.lineTo(x + width, y + depth - radius)
  path.quadraticCurveTo(x + width, y + depth, x + width - radius, y + depth)
  path.lineTo(x + radius, y + depth)
  path.quadraticCurveTo(x, y + depth, x, y + depth - radius)
  path.lineTo(x, y + radius)
  path.quadraticCurveTo(x, y, x + radius, y)
  path.closePath()
  return path
}

function Box({ position = [0, 0, 0], size, color = ICE, metalness = 0.65, roughness = 0.36, material, ...props }) {
  return (
    <mesh position={position} castShadow receiveShadow material={material} {...props}>
      <boxGeometry args={size} />
      {!material && <meshStandardMaterial color={color} metalness={metalness} roughness={roughness} />}
    </mesh>
  )
}

// Repeated pins, capacitors, and traces share draw calls rather than hundreds of meshes.
function BoxInstances({ items, color, metalness = 0.55, roughness = 0.4, castShadow = true, material }) {
  const ref = useRef()
  useLayoutEffect(() => {
    const transform = new THREE.Object3D()
    items.forEach((item, i) => {
      transform.position.set(...item.position)
      transform.rotation.set(0, item.rotation || 0, 0)
      transform.scale.set(...item.size)
      transform.updateMatrix()
      ref.current.setMatrixAt(i, transform.matrix)
    })
    ref.current.instanceMatrix.needsUpdate = true
    ref.current.computeBoundingSphere()
  }, [items])
  if (!items.length) return null
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, items.length]} material={material} castShadow={castShadow} receiveShadow>
      <boxGeometry args={[1, 1, 1]} />
      {!material && <meshStandardMaterial color={color} metalness={metalness} roughness={roughness} />}
    </instancedMesh>
  )
}

function Board() {
  const geometries = useMemo(() => {
    const shape = roundedPath(new THREE.Shape(), 6.8, 4.6, 0.24)
    for (const x of [-3.07, 3.07]) {
      for (const z of [-1.97, 1.97]) {
        const hole = new THREE.Path()
        hole.absarc(x, z, 0.115, 0, Math.PI * 2, true)
        shape.holes.push(hole)
      }
    }
    const rim = roundedPath(new THREE.Shape(), 6.86, 4.66, 0.27)
    rim.holes.push(roundedPath(new THREE.Path(), 6.63, 4.43, 0.2))
    return {
      board: new THREE.ExtrudeGeometry(shape, { depth: 0.18, bevelEnabled: false, curveSegments: 8 }),
      rim: new THREE.ExtrudeGeometry(rim, { depth: 0.095, bevelEnabled: false, curveSegments: 8 }),
    }
  }, [])
  useEffect(() => () => Object.values(geometries).forEach((geometry) => geometry.dispose()), [geometries])
  const { traces, pads, resistors, ceramic, terminals } = useMemo(() => {
    const traces = []
    const pads = []
    const resistors = []
    const ceramic = []
    const terminals = []
    // Parallel routed buses: the asymmetry and angled corners read as an actual PCB.
    const segment = (x1, z1, x2, z2, width = 0.011) => {
      const dx = x2 - x1
      const dz = z2 - z1
      traces.push({ position: [(x1 + x2) / 2, TOP + 0.003, (z1 + z2) / 2], size: [Math.hypot(dx, dz), 0.004, width], rotation: -Math.atan2(dz, dx) })
    }
    for (let i = 0; i < 11; i += 1) {
      const offset = i * 0.043
      segment(-0.24 + offset, -1.29, 0.11 + offset, -0.93)
      segment(0.11 + offset, -0.93, 0.11 + offset, -0.34)
      segment(0.11 + offset, -0.34, 0.39 + offset, -0.08)
      segment(-1.6, 0.97 + offset, -1.8, 1.17 + offset)
      segment(-1.8, 1.17 + offset, -1.8, 1.7 + offset)
      segment(-1.8, 1.7 + offset, 0.26, 1.7 + offset)
    }
    for (let i = 0; i < 8; i += 1) {
      const offset = i * 0.046
      segment(-2.98 + offset, -1.6, -2.98 + offset, -0.1)
      segment(-2.98 + offset, -0.1, -2.72 + offset, 0.16)
      segment(-2.72 + offset, 0.16, -2.72 + offset, 0.38)
      segment(1.91, -1.57 + offset, 2.3, -1.57 + offset)
      segment(2.3, -1.57 + offset, 2.61, -1.26 + offset)
      segment(1.82, 0.93 + offset, 2.4, 0.93 + offset)
    }
    for (let i = 0; i < 23; i += 1) {
      const x = -2.64 + i * 0.224
      const z = i % 2 === 0 ? -1.77 : 1.57
      const part = { position: [x, TOP + 0.037, z], size: [0.105, 0.071, 0.052] }
      ;(i % 3 === 0 ? ceramic : resistors).push(part)
      for (const sign of [-1, 1]) terminals.push({ position: [x + sign * 0.052, TOP + 0.037, z], size: [0.028, 0.074, 0.057] })
      pads.push({ position: [x, TOP + 0.006, z + 0.103], size: [0.054, 0.008, 0.045] })
    }
    for (let i = 0; i < 9; i += 1) {
      const x = -2.58 + (i % 3) * 0.21
      const z = -1.3 + Math.floor(i / 3) * 0.31
      ceramic.push({ position: [x, TOP + 0.058, z], size: [0.12, 0.115, 0.19] })
      for (const sign of [-1, 1]) terminals.push({ position: [x, TOP + 0.057, z + sign * 0.084], size: [0.124, 0.118, 0.039] })
    }
    return { traces, pads, resistors, ceramic, terminals }
  }, [])
  return (
    <group>
      <mesh geometry={geometries.board} position={[0, 0, 0]} rotation={[-Math.PI / 2, 0, 0]} castShadow receiveShadow>
        <meshStandardMaterial color="#352337" roughness={0.5} metalness={0.27} />
      </mesh>
      <mesh geometry={geometries.rim} position={[0, 0.031, 0]} rotation={[-Math.PI / 2, 0, 0]} castShadow receiveShadow>
        <meshStandardMaterial color="#abb8c8" metalness={0.88} roughness={0.3} />
      </mesh>
      {[-0.001, 0.016].map((y) => <mesh key={y} geometry={geometries.rim} position={[0, y, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <meshStandardMaterial color={y < 0 ? '#151823' : '#786076'} metalness={0.65} roughness={0.47} />
      </mesh>)}
      <BoxInstances items={traces} color="#9a8396" metalness={0.72} roughness={0.46} castShadow={false} />
      <BoxInstances items={pads} color="#b7a474" />
      <BoxInstances items={resistors} color="#252634" metalness={0.1} />
      <BoxInstances items={ceramic} color="#c7b599" metalness={0.12} />
      <BoxInstances items={terminals} color="#aeb8c4" metalness={0.8} />
      {[-3.07, 3.07].flatMap((x) => [-1.97, 1.97].map((z) => <Mount key={`${x}-${z}`} x={x} z={z} />))}
      <GPIO />
      <Ports />
      <PowerParts />
      <Html position={[1.16, TOP + 0.016, 1.99]} center distanceFactor={11} style={{ pointerEvents: 'none' }}>
        <div style={{ color: '#c1aeb9', font: '600 8px system-ui, sans-serif', letterSpacing: '0.2em', whiteSpace: 'nowrap', opacity: 0.78 }}>HETEROGENEOUS / REV. 04</div>
      </Html>
    </group>
  )
}

function Mount({ x, z }) {
  return (
    <group position={[x, 0, z]}>
      <mesh position={[0, 0.192, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <ringGeometry args={[0.112, 0.197, 24]} />
        <meshStandardMaterial color="#c4b28b" metalness={0.88} roughness={0.35} side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[0, 0.218, 0]} castShadow>
        <cylinderGeometry args={[0.105, 0.105, 0.067, 20]} />
        <meshStandardMaterial color="#bbc5d1" metalness={0.92} roughness={0.28} />
      </mesh>
      <Box position={[0, 0.255, 0]} size={[0.124, 0.005, 0.022]} color="#4e5360" />
      <Box position={[0, 0.256, 0]} size={[0.022, 0.005, 0.124]} color="#4e5360" />
      <mesh position={[0, -0.125, 0]} castShadow>
        <cylinderGeometry args={[0.135, 0.15, 0.25, 12]} />
        <meshStandardMaterial color="#333744" metalness={0.8} roughness={0.35} />
      </mesh>
    </group>
  )
}

function GPIO() {
  const pins = useMemo(() => Array.from({ length: 40 }, (_, i) => ({
    position: [-1.6 + Math.floor(i / 2) * 0.168, TOP + 0.34, -2.035 + (i % 2) * 0.17], size: [0.042, 0.49, 0.042],
  })), [])
  return (
    <group>
      <Box position={[0, TOP + 0.084, -1.95]} size={[3.5, 0.16, 0.37]} color="#20212c" metalness={0.14} />
      <BoxInstances items={pins} color="#d3ac5c" metalness={0.86} roughness={0.27} />
      <Box position={[-1.73, TOP + 0.169, -1.95]} size={[0.057, 0.022, 0.27]} color={GOLD} />
    </group>
  )
}

// Connector shells are hollow, with visible tongues, contacts, seams and retaining tabs.
function Ports() {
  const contacts = useMemo(() => Array.from({ length: 8 }, (_, i) => ({ position: [0.52, 0.35, -0.39 + i * 0.11], size: [0.19, 0.025, 0.031] })), [])
  const usbContacts = useMemo(() => Array.from({ length: 8 }, (_, i) => ({ position: [0.49, 0.2 + Math.floor(i / 4) * 0.34, -0.22 + (i % 4) * 0.145], size: [0.17, 0.024, 0.052] })), [])
  return (
    <group>
      <group position={[3.08, TOP, -0.7]}>
        <Box position={[0, 0.045, 0]} size={[1.05, 0.09, 1.17]} />
        <Box position={[0, 0.85, 0]} size={[1.05, 0.075, 1.17]} />
        {[-0.555, 0.555].map((z) => <Box key={z} position={[0, 0.44, z]} size={[1.05, 0.79, 0.062]} />)}
        <Box position={[-0.48, 0.44, 0]} size={[0.08, 0.76, 1.1]} color="#868f9e" />
        <Box position={[-0.39, 0.4, 0]} size={[0.08, 0.61, 0.97]} color="#151720" metalness={0.1} />
        <Box position={[0.27, 0.11, 0]} size={[0.54, 0.095, 0.99]} color="#262a36" metalness={0.2} />
        <BoxInstances items={contacts} color="#dab867" metalness={0.85} />
        {[-0.435, 0.435].map((z, i) => <Box key={z} position={[0.545, 0.72, z]} size={[0.013, 0.08, 0.105]} color={i ? '#cf9c38' : '#889f78'} metalness={0.12} />)}
        {[-0.34, 0.34].map((z) => <Box key={z} position={[0.02, 0.892, z]} size={[0.32, 0.004, 0.012]} color="#718090" />)}
      </group>
      <group position={[3.1, TOP, 0.91]}>
        <Box position={[0, 0.045, 0]} size={[1.01, 0.09, 0.94]} />
        <Box position={[0, 0.73, 0]} size={[1.01, 0.065, 0.94]} />
        <Box position={[0, 0.375, 0]} size={[1.01, 0.043, 0.94]} />
        {[-0.443, 0.443].map((z) => <Box key={z} position={[0, 0.385, z]} size={[1.01, 0.67, 0.055]} />)}
        <Box position={[-0.46, 0.38, 0]} size={[0.07, 0.64, 0.86]} color="#4b5260" />
        {[0.17, 0.51].map((y) => <Box key={y} position={[0.12, y, 0]} size={[0.75, 0.08, 0.77]} color="#33465c" metalness={0.12} />)}
        <BoxInstances items={usbContacts} color="#d8ba7c" />
        {[0.19, 0.53].flatMap((y) => [-0.455, 0.455].map((z) => <Box key={`${y}-${z}`} position={[0.4, y, z]} size={[0.12, 0.07, 0.025]} color="#e0e4eb" />))}
      </group>
      <SmallPort x={-1.48} width={0.78} type="hdmi" />
      <SmallPort x={-0.24} width={0.61} type="usb-c" />
      <Box position={[-2.43, TOP + 0.085, 1.81]} size={[0.38, 0.17, 0.36]} color="#31343d" metalness={0.1} />
      <mesh position={[-2.43, TOP + 0.199, 1.81]} castShadow>
        <cylinderGeometry args={[0.113, 0.113, 0.065, 20]} />
        <meshStandardMaterial color="#b4bdc8" metalness={0.8} roughness={0.3} />
      </mesh>
    </group>
  )
}

function SmallPort({ x, width, type }) {
  const height = type === 'hdmi' ? 0.25 : 0.21
  const contacts = useMemo(() => Array.from({ length: type === 'hdmi' ? 10 : 8 }, (_, i) => ({
    position: [-width * 0.34 + i * width * 0.075, height * 0.5 + 0.034, 0.27], size: [0.019, 0.012, 0.08],
  })), [width, height, type])
  return (
    <group position={[x, TOP, 2.18]}>
      <Box position={[0, 0.025, 0]} size={[width, 0.045, 0.57]} />
      <Box position={[0, height, 0]} size={[width, 0.042, 0.57]} />
      {[-1, 1].map((side) => <Box key={side} position={[side * (width / 2 - 0.024), height / 2, 0]} size={[0.047, height, 0.57]} />)}
      <Box position={[0, height / 2, -0.26]} size={[width - 0.075, height - 0.025, 0.04]} color="#272936" metalness={0.1} />
      <Box position={[0, height / 2, 0.06]} size={[width * 0.76, 0.055, 0.44]} color="#262a33" metalness={0.1} />
      <BoxInstances items={contacts} color="#cdb17b" />
    </group>
  )
}

function PowerParts() {
  return (
    <group>
      {[-0.65, -0.12].map((z) => <group key={z} position={[-2.23, TOP, z]}>
        <Box position={[0, 0.108, 0]} size={[0.4, 0.215, 0.34]} color="#5c5c65" metalness={0.37} />
        <Box position={[0, 0.221, 0]} size={[0.31, 0.013, 0.26]} color="#929098" metalness={0.6} />
        <Box position={[0, 0.229, 0]} size={[0.15, 0.005, 0.016]} color="#514a59" />
      </group>)}
      {[0.2, 0.71].map((x) => <group key={x} position={[x, TOP, -1.45]}>
        <mesh position={[0, 0.15, 0]} castShadow receiveShadow>
          <cylinderGeometry args={[0.145, 0.145, 0.3, 20]} />
          <meshStandardMaterial color="#b1bac8" metalness={0.82} roughness={0.32} />
        </mesh>
        <mesh position={[0, 0.305, 0]}>
          <cylinderGeometry args={[0.128, 0.128, 0.014, 20]} />
          <meshStandardMaterial color="#e1e4e9" metalness={0.7} roughness={0.36} />
        </mesh>
        <Box position={[0, 0.316, 0]} size={[0.17, 0.006, 0.015]} color="#68707e" />
      </group>)}
    </group>
  )
}

function SelectionRim({ width, depth, y, material }) {
  const items = useMemo(() => [
    { position: [0, y, -depth / 2], size: [width, 0.023, 0.025] },
    { position: [0, y, depth / 2], size: [width, 0.023, 0.025] },
    { position: [-width / 2, y, 0], size: [0.025, 0.023, depth] },
    { position: [width / 2, y, 0], size: [0.025, 0.023, depth] },
  ], [width, depth, y])
  return <BoxInstances items={items} material={material} castShadow={false} />
}

const labelStyle = {
  fontFamily: 'Inter, ui-sans-serif, system-ui, sans-serif', fontSize: 10, fontWeight: 650,
  letterSpacing: '0.1em', color: '#f4f0e9', whiteSpace: 'nowrap', pointerEvents: 'none',
  background: 'rgba(26, 25, 33, .86)', border: '1px solid rgba(223, 222, 233, .18)',
  padding: '5px 9px', borderRadius: 6, boxShadow: '0 3px 12px rgba(0,0,0,.13)',
}

function Chip({ device, selectedId, selectedCore, onSelect, temperature, active, running, progress, thermalView, exploded }) {
  const { id, label, position, size: [width, depth], height, lift } = device
  const group = useRef()
  const indicator = useRef()
  const [hovered, setHovered] = useState(false)
  const cursorHover = React.useContext(HoverContext)
  const selected = selectedId === id
  const materials = useMemo(() => ({
    surface: new THREE.MeshStandardMaterial({ color: ICE, metalness: 0.78, roughness: 0.34 }),
    rim: new THREE.MeshStandardMaterial({ color: '#605463', metalness: 0.65, roughness: 0.31, emissive: GOLD, emissiveIntensity: 0 }),
  }), [])
  useEffect(() => () => Object.values(materials).forEach((material) => material.dispose()), [materials])
  const targetColor = useMemo(() => thermalView ? thermalColor(temperature) : new THREE.Color(id === 'dsp' ? '#a6a7b4' : ICE), [thermalView, temperature, id])
  const rimTarget = useMemo(() => new THREE.Color(selected || hovered ? GOLD : '#605463'), [selected, hovered])
  const brush = useMemo(() => Array.from({ length: id === 'gpu' ? 11 : 15 }, (_, i) => ({
    position: [-width * 0.38 + (i / (id === 'gpu' ? 10 : 14)) * width * 0.76, height + 0.002, 0],
    size: [0.006, 0.003, depth * 0.72],
  })), [width, depth, height, id])
  const pins = useMemo(() => {
    const result = []
    const count = id === 'npu' ? 10 : 8
    for (let i = 0; i < count; i += 1) {
      const x = -width * 0.4 + (i / (count - 1)) * width * 0.8
      const z = -depth * 0.38 + (i / (count - 1)) * depth * 0.76
      for (const sign of [-1, 1]) {
        result.push({ position: [x, 0.064, sign * (depth / 2 + 0.04)], size: [0.042, 0.042, 0.14] })
        result.push({ position: [sign * (width / 2 + 0.04), 0.064, z], size: [0.14, 0.042, 0.042] })
      }
    }
    return result
  }, [width, depth, id])
  const ribs = useMemo(() => Array.from({ length: 10 }, (_, i) => ({
    position: [-width * 0.4 + i * width * 0.8 / 9, height - 0.095, 0], size: [0.07, 0.19, depth * 0.82],
  })), [width, depth, height])
  const ratio = typeof progress === 'number' && Number.isFinite(progress) ? clamp(progress > 1 ? progress / 100 : progress, 0, 1) : 0
  useFrame(({ clock }, delta) => {
    if (!group.current) return
    group.current.position.y = damp(group.current.position.y, TOP + (exploded ? lift : 0) + (hovered ? 0.055 : 0), delta)
    materials.surface.color.lerp(targetColor, 1 - Math.exp(-delta * 7))
    materials.rim.color.lerp(rimTarget, 1 - Math.exp(-delta * 10))
    const pulse = active && running ? 0.11 + (Math.sin(clock.elapsedTime * 4.3) + 1) * 0.095 : 0
    materials.surface.emissive.copy(targetColor)
    materials.surface.emissiveIntensity = damp(materials.surface.emissiveIntensity, pulse, delta)
    materials.rim.emissiveIntensity = damp(materials.rim.emissiveIntensity, selected ? 0.24 : hovered ? 0.14 : 0, delta)
    if (indicator.current) indicator.current.material.emissiveIntensity = active && running ? 0.7 + Math.sin(clock.elapsedTime * 4.3) * 0.3 : 0.14
  })
  const stopSelect = (event) => { event.stopPropagation(); onSelect?.(id, null) }
  return (
    <group>
      <Box position={[position[0], TOP + 0.008, position[2]]} size={[width + 0.2, 0.012, depth + 0.2]} color="#4c3b50" metalness={0.3} />
      {exploded && <group position={[position[0], TOP, position[2]]}>
        {[-1, 1].flatMap((x) => [-1, 1].map((z) => <Box key={`${x}-${z}`} position={[x * width * 0.43, lift / 2, z * depth * 0.42]} size={[0.008, lift, 0.008]} color="#76616d" metalness={0.2} />))}
      </group>}
      <group ref={group} position={[position[0], TOP, position[2]]} onClick={stopSelect}
        onPointerOver={(event) => { event.stopPropagation(); setHovered(true); cursorHover(id, true) }}
        onPointerOut={() => { setHovered(false); cursorHover(id, false) }}>
        <RoundedBox args={[width, 0.125, depth]} radius={0.048} smoothness={3} position={[0, 0.066, 0]} castShadow receiveShadow>
          <meshStandardMaterial color="#272633" metalness={0.3} roughness={0.4} />
        </RoundedBox>
        <BoxInstances items={pins} color="#b6bbc6" metalness={0.83} roughness={0.31} />
        <SelectionRim width={width - 0.05} depth={depth - 0.05} y={0.13} material={materials.rim} />
        {id === 'cpu' ? <>
          <Box position={[0, 0.154, 0]} size={[width - 0.15, 0.052, depth - 0.15]} color="#595864" />
          {[0, 1, 2, 3].map((core) => <Core key={core} index={core} selected={selected && selectedCore === core}
            allSelected={selected && selectedCore == null} onSelect={onSelect} material={materials.surface} exploded={exploded} />)}
        </> : id === 'gpu' ? <>
          <RoundedBox args={[width - 0.1, 0.16, depth - 0.1]} radius={0.035} smoothness={3} position={[0, 0.21, 0]} material={materials.surface} castShadow receiveShadow />
          <BoxInstances items={ribs} material={materials.surface} />
          <Box position={[0, height + 0.005, 0]} size={[width * 0.75, 0.035, 0.19]} material={materials.surface} />
          {[-1, 1].map((side) => <Box key={side} position={[side * width * 0.42, 0.23, 0]} size={[0.043, 0.21, depth * 0.92]} color="#898e9b" />)}
        </> : <>
          <RoundedBox args={[width - 0.11, height - 0.12, depth - 0.11]} radius={0.045} smoothness={3}
            position={[0, (height + 0.12) / 2, 0]} material={materials.surface} castShadow receiveShadow />
          <BoxInstances items={brush} color="#919aa9" metalness={0.77} roughness={0.45} castShadow={false} />
          <mesh position={[-width * 0.31, height + 0.004, depth * 0.3]} rotation={[-Math.PI / 2, 0, 0]}>
            <circleGeometry args={[0.022, 12]} /><meshStandardMaterial color="#4e535e" roughness={0.6} />
          </mesh>
        </>}
        <mesh ref={indicator} position={[width * 0.32, 0.142, depth * 0.43]}>
          <boxGeometry args={[0.11, 0.025, 0.032]} />
          <meshStandardMaterial color={active ? GOLD : '#606773'} emissive={GOLD} emissiveIntensity={0.14} />
        </mesh>
        {active && <>
          <Box position={[0, 0.145, depth * 0.435]} size={[width * 0.48, 0.018, 0.017]} color="#62594a" />
          {ratio > 0 && <Box position={[-width * 0.24 * (1 - ratio), 0.149, depth * 0.435]} size={[width * 0.48 * ratio, 0.019, 0.019]} color={GOLD} />}
        </>}
        <Html position={[0, height + (id === 'cpu' ? 0.3 : 0.23), 0]} center distanceFactor={10} zIndexRange={[30, 0]} style={{ pointerEvents: 'none' }}>
          <div style={{ ...labelStyle, borderColor: selected ? 'rgba(237,184,76,.74)' : labelStyle.border, color: selected ? '#f4d48a' : '#f4f0e9' }}>
            {label}{id === 'cpu' && selected && selectedCore != null && <span style={{ fontSize: 8, marginLeft: 6, opacity: 0.85 }}>CORE {selectedCore + 1}</span>}
            {thermalView && <span style={{ marginLeft: 7, letterSpacing: 0, fontVariantNumeric: 'tabular-nums', color: targetColor.getStyle() }}>{Math.round(temperature)}°C</span>}
            {active && running && <span style={{ display: 'inline-block', width: 4, height: 4, borderRadius: '50%', background: GOLD, marginLeft: 6, verticalAlign: 'middle' }} />}
          </div>
        </Html>
      </group>
    </group>
  )
}

function Core({ index, selected, allSelected, onSelect, material, exploded }) {
  const ref = useRef()
  const [hovered, setHovered] = useState(false)
  const cursorHover = React.useContext(HoverContext)
  const hoverToken = `cpu-${index}`
  const x = index % 2 === 0 ? -0.328 : 0.328
  const z = index < 2 ? -0.313 : 0.313
  const rimMaterial = useMemo(() => new THREE.MeshStandardMaterial({ color: GOLD, metalness: 0.72, roughness: 0.35, emissive: GOLD, emissiveIntensity: 0.18 }), [])
  useEffect(() => () => rimMaterial.dispose(), [rimMaterial])
  useFrame((_, delta) => {
    if (ref.current) ref.current.position.y = damp(ref.current.position.y, 0.229 + (selected ? 0.038 : 0) + (hovered ? 0.054 : 0) + (exploded ? 0.15 : 0), delta, 11)
  })
  return (
    <group ref={ref} position={[x, 0.229, z]}
      onClick={(event) => { event.stopPropagation(); onSelect?.('cpu', index) }}
      onPointerOver={(event) => { event.stopPropagation(); setHovered(true); cursorHover(hoverToken, true) }}
      onPointerOut={() => { setHovered(false); cursorHover(hoverToken, false) }}>
      <RoundedBox args={[0.592, 0.11, 0.564]} radius={0.024} smoothness={3} material={material} castShadow receiveShadow />
      {(selected || allSelected || hovered) && <SelectionRim width={0.587} depth={0.559} y={0.058} material={rimMaterial} />}
      <Box position={[0, 0.056, -0.199]} size={[0.4, 0.003, 0.007]} color="#87909e" />
      <Html position={[0, 0.067, 0.08]} center distanceFactor={9} zIndexRange={[20, 0]} style={{ pointerEvents: 'none' }}>
        <div style={{ color: selected || hovered ? '#f8d791' : '#353643', font: '700 9px ui-monospace, monospace', pointerEvents: 'none', textShadow: '0 1px 1px rgba(255,255,255,.2)' }}>{String(index + 1).padStart(2, '0')}</div>
      </Html>
    </group>
  )
}

function CameraRig({ view, resetKey }) {
  const controls = useRef()
  const { camera, size } = useThree()
  const destination = useRef(new THREE.Vector3())
  const target = useMemo(() => new THREE.Vector3(0, 0.25, 0), [])
  const transitioning = useRef(true)
  const initialized = useRef(false)
  useLayoutEffect(() => {
    const aspect = size.width / Math.max(1, size.height)
    const fit = clamp(1.08 / Math.max(aspect, 0.4), 1, 2.7)
    destination.current.set(...(view === 'top' ? [0, 12.9 * fit, 0.025] : [7 * fit, 8 * fit, 9 * fit]))
    transitioning.current = true
    if (controls.current) controls.current.enabled = false
    if (!initialized.current) {
      camera.position.copy(destination.current)
      camera.lookAt(target)
      controls.current?.target.copy(target)
      initialized.current = true
    }
  }, [view, resetKey, size.width, size.height, camera, target])
  useFrame((_, delta) => {
    if (!transitioning.current || !controls.current) return
    const factor = 1 - Math.exp(-Math.min(delta, 0.1) * 6)
    camera.position.lerp(destination.current, factor)
    controls.current.target.lerp(target, factor)
    controls.current.update()
    if (camera.position.distanceToSquared(destination.current) < 0.001 && controls.current.target.distanceToSquared(target) < 0.001) {
      camera.position.copy(destination.current)
      controls.current.target.copy(target)
      controls.current.update()
      transitioning.current = false
      controls.current.enabled = true
    }
  })
  return <OrbitControls ref={controls} makeDefault enablePan={false} enableZoom enableRotate enableDamping dampingFactor={0.075}
    rotateSpeed={0.65} zoomSpeed={0.75} minDistance={7} maxDistance={40} minPolarAngle={0.001} maxPolarAngle={Math.PI * 0.455}
    target={[0, 0.25, 0]} onStart={() => { transitioning.current = false }} />
}

function ContextGuard({ onLost }) {
  const { gl } = useThree()
  useEffect(() => {
    const canvas = gl.domElement
    const lost = (event) => { event.preventDefault(); onLost() }
    canvas.addEventListener('webglcontextlost', lost)
    return () => canvas.removeEventListener('webglcontextlost', lost)
  }, [gl, onLost])
  return null
}

function Assembly(props) {
  const ref = useRef()
  const [hoverToken, setHoverToken] = useState(null)
  const cursorHover = React.useCallback((token, entering) => {
    setHoverToken((current) => entering ? token : current === token ? null : current)
  }, [])
  // A single cursor owner avoids nested chip/core hover handlers fighting each other.
  useCursor(hoverToken !== null)
  useFrame((_, delta) => {
    if (ref.current) {
      ref.current.position.y = damp(ref.current.position.y, 0, delta, 4)
      ref.current.rotation.x = damp(ref.current.rotation.x, 0, delta, 4)
    }
  })
  return <HoverContext.Provider value={cursorHover}>
    <group ref={ref} position={[0, 0.15, 0]} rotation={[0.018, 0, 0]}>
      <Board />
      {DEVICES.map((device) => <Chip key={device.id} device={device} {...props} temperature={temperatureFor(props.temperatures, device.id)} active={props.activeId === device.id} />)}
    </group>
  </HoverContext.Provider>
}

function LightingAndFloor() {
  return <>
    <color attach="background" args={['#302139']} />
    <fog attach="fog" args={['#302139', 35, 68]} />
    <ambientLight intensity={0.75} color="#f4eff5" />
    <hemisphereLight args={['#eef4ff', '#918188', 1.55]} />
    <directionalLight position={[-3, 8, 5]} intensity={3.4} color="#fff2dc" castShadow shadow-mapSize={[1024, 1024]}
      shadow-camera-left={-6} shadow-camera-right={6} shadow-camera-top={6} shadow-camera-bottom={-6}
      shadow-camera-near={0.5} shadow-camera-far={22} shadow-bias={-0.00025} shadow-normalBias={0.035} />
    <directionalLight position={[4, 5, -5]} intensity={2.25} color="#dbe8ff" />
    <spotLight position={[-5, 4, -2]} intensity={38} color="#ead6ff" angle={0.7} penumbra={0.85} distance={20} decay={2} />
    {/* Locally rendered softboxes give brushed metal reflections; no HDRI or URLs. */}
    <Environment frames={1} resolution={128}>
      <color attach="background" args={['#625c68']} />
      <Lightformer form="rect" color="#fff0df" intensity={3.4} position={[-3, 6, 2]} rotation={[Math.PI / 2, 0, 0]} scale={[9, 4, 1]} />
      <Lightformer form="rect" color="#dce9ff" intensity={2.3} position={[5, 3, -4]} rotation={[0, -Math.PI / 3, 0]} scale={[4, 6, 1]} />
      <Lightformer form="rect" color="#f8f3ee" intensity={1.8} position={[-5, 1, -1]} rotation={[0, Math.PI / 2, 0]} scale={[2, 5, 1]} />
    </Environment>
    <mesh position={[0, -0.268, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
      <planeGeometry args={[200, 200]} /><meshStandardMaterial color="#17101f" roughness={0.9} metalness={0.08} />
    </mesh>
  </>
}

class SceneBoundary extends Component {
  state = { failed: false }
  static getDerivedStateFromError() { return { failed: true } }
  render() { return this.state.failed ? this.props.fallback : this.props.children }
}

function Fallback({ selectedId, selectedCore, onSelect, temperatures, checking = false, onRetry }) {
  return <div role="region" aria-label="Hardware renderer fallback" style={{ width: '100%', height: '100%', minHeight: 280, boxSizing: 'border-box', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 26, background: '#302139', color: '#e3d9e9', fontFamily: 'ui-sans-serif, system-ui, sans-serif', textAlign: 'center' }}>
    <div style={{ width: 46, height: 46, border: '1px solid #ad9eaf', borderRadius: 10, display: 'grid', placeItems: 'center', marginBottom: 17 }} aria-hidden="true">
      <svg width="25" height="25" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.3"><rect x="5" y="5" width="14" height="14" rx="2" /><path d="M9 1v4m6-4v4M9 19v4m6-4v4M1 9h4m-4 6h4m14-6h4m-4 6h4M9 9h6v6H9z" /></svg>
    </div>
    <strong style={{ fontSize: 17, fontWeight: 600 }}>{checking ? 'Preparing the hardware view' : '3D hardware view unavailable'}</strong>
    <p style={{ maxWidth: 360, fontSize: 12, lineHeight: 1.7, color: '#786c7e', margin: '9px 0 20px' }}>{checking ? 'Checking local WebGL support.' : 'WebGL could not start or its graphics context was lost. The scheduler still works; select a device below.'}</p>
    <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 8 }}>
      {DEVICES.map(({ id, label }) => <button key={id} type="button" aria-pressed={selectedId === id} onClick={() => onSelect?.(id, null)}
        style={{ cursor: 'pointer', border: `1px solid ${selectedId === id ? '#c59a39' : '#cfc7ce'}`, borderRadius: 8, padding: '10px 13px', color: '#352b3a', background: selectedId === id ? '#f3dfb0' : '#f7f4f0', font: '600 11px ui-sans-serif, system-ui, sans-serif' }}>
        {label} <span style={{ marginLeft: 5, color: '#847486', fontWeight: 400 }}>{Math.round(temperatureFor(temperatures, id))}°C</span>
      </button>)}
    </div>
    {selectedId === 'cpu' && <div role="group" aria-label="CPU core selection" style={{ display: 'flex', gap: 6, marginTop: 10 }}>
      {[0, 1, 2, 3].map((core) => <button key={core} type="button" aria-pressed={selectedCore === core} onClick={() => onSelect?.('cpu', core)} style={{ border: '1px solid #cfc7ce', borderRadius: 5, background: selectedCore === core ? '#f3dfb0' : 'transparent', color: '#65556b', padding: '6px 10px', cursor: 'pointer', fontSize: 10 }}>Core {core}</button>)}
    </div>}
    {!checking && onRetry && <button type="button" onClick={onRetry} style={{ marginTop: 20, border: 0, background: 'transparent', textDecoration: 'underline', color: '#76647c', cursor: 'pointer', fontSize: 11 }}>Retry 3D renderer</button>}
  </div>
}

function supportsWebGL() {
  if (typeof document === 'undefined') return false
  try {
    const canvas = document.createElement('canvas')
    const context = canvas.getContext('webgl2', { failIfMajorPerformanceCaveat: false })
    if (!context) return false
    context.getExtension('WEBGL_lose_context')?.loseContext()
    return true
  } catch { return false }
}

export default function HardwareScene({ selectedId, selectedCore, onSelect, temperatures, activeId, running, progress, thermalView, exploded, view, resetKey }) {
  const [available, setAvailable] = useState(null)
  const [attempt, setAttempt] = useState(0)
  const props = { selectedId, selectedCore, onSelect, temperatures, activeId, running, progress, thermalView, exploded, view, resetKey }
  useEffect(() => { setAvailable(supportsWebGL()) }, [attempt])
  const handleLost = React.useCallback(() => setAvailable(false), [])
  const retry = () => { setAvailable(null); setAttempt((value) => value + 1) }
  const fallback = <Fallback {...props} checking={available === null} onRetry={retry} />
  return <div style={{ position: 'relative', width: '100%', height: '100%', overflow: 'hidden' }}>
    {available ? <SceneBoundary key={attempt} fallback={<Fallback {...props} onRetry={retry} />}>
      <Canvas shadows dpr={[1, 1.5]} camera={{ position: [7, 8, 9], fov: 39, near: 0.1, far: 100 }}
        gl={{ antialias: true, alpha: false, powerPreference: 'high-performance' }} fallback={fallback}
        onCreated={({ gl }) => { gl.toneMapping = THREE.ACESFilmicToneMapping; gl.toneMappingExposure = 1.05 }}
        style={{ width: '100%', height: '100%', touchAction: 'none' }} aria-label="Interactive illustrative heterogeneous edge-device carrier; select processor packages or CPU cores">
        <ContextGuard onLost={handleLost} />
        <Suspense fallback={null}>
          <LightingAndFloor />
          <Assembly {...props} />
          <CameraRig view={view} resetKey={resetKey} />
        </Suspense>
      </Canvas>
    </SceneBoundary> : fallback}
  </div>
}
