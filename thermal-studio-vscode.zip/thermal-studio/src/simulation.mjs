export const DEVICES = [
  { id: 'cpu', name: 'Edge CPU', short: 'CPU', architecture: 'General-purpose · 4 virtual cores', throughput: 78, bandwidth: 1500, idle: 1, compute: 5.4, memory: 1, r: 2.6, c: 24, mix: [1, 1, 1.2, .95, 1], color: '#d2bde7' },
  { id: 'gpu', name: 'Mobile GPU', short: 'GPU', architecture: 'Parallel compute accelerator', throughput: 235, bandwidth: 3900, idle: 1.8, compute: 9.4, memory: 1.7, r: 2.1, c: 31, mix: [.72, .80, .90, .95, 1.18], color: '#ec9a76' },
  { id: 'npu', name: 'Edge NPU', short: 'NPU', architecture: 'Neural processing accelerator', throughput: 205, bandwidth: 2300, idle: .8, compute: 4, memory: 1.2, r: 3, c: 19, mix: [.62, .92, 1.65, .75, 1.05], color: '#a7cec6' },
  { id: 'mobile_cpu', name: 'Mobile CPU', short: 'M-CPU', architecture: 'Low-power general-purpose processor', throughput: 32, bandwidth: 800, idle: .4, compute: 2.8, memory: .6, r: 3.8, c: 12, mix: [1, 1, 1.1, .95, 1], color: '#a6b9d2' },
  { id: 'dsp', name: 'Embedded DSP', short: 'DSP', architecture: 'Signal-processing accelerator', throughput: 160, bandwidth: 2000, idle: .6, compute: 3.2, memory: .9, r: 2.8, c: 16, mix: [.55, .88, 1.40, .80, 1.10], color: '#f0be5b' },
];

export const WORKLOADS = [
  { id: 'vision', name: 'Vision CNN', detail: 'Image recognition', mix: [.58, .13, .02, .17, .10], sparsity: .2, icon: 'scan' },
  { id: 'transformer', name: 'Transformer', detail: 'Attention & language', mix: [.02, .46, .34, .10, .08], sparsity: .15, icon: 'network' },
  { id: 'audio', name: 'Audio CNN', detail: 'Signal classification', mix: [.42, .13, .02, .23, .20], sparsity: .25, icon: 'audio' },
  { id: 'sparse', name: 'Sparse CNN', detail: 'Pruned inference', mix: [.58, .13, .02, .17, .10], sparsity: .8, icon: 'layers' },
];

export const POLICIES = [
  { id: 'adaptive', name: 'Adaptive', weights: [.30, .35, .35], description: 'Balances execution time, energy and temperature.' },
  { id: 'latency', name: 'Latency', weights: [.85, .10, .05], description: 'Prioritizes the fastest thermally safe processor.' },
  { id: 'energy', name: 'Energy', weights: [.10, .85, .05], description: 'Prioritizes the lowest-energy safe processor.' },
  { id: 'thermal', name: 'Thermal', weights: [.10, .10, .80], description: 'Prioritizes the coolest safe processor.' },
];

export const DEFAULT_CONFIG = {
  ambient: 25, initial: 46, complexity: 62, workload: 'vision', sparsity: .2,
  holdSeconds: 0, threshold: 75, deadline: 120, policy: 'adaptive', overrides: {}, disabled: [],
};

export function temperatureAt(t, ambient, initial, power, r, c) {
  const fraction = -Math.expm1(-Math.max(0, t) / (r * c));
  return initial + (ambient + power * r - initial) * fraction;
}

export function metricsFor(config) {
  const workload = WORKLOADS.find(w => w.id === config.workload) ?? WORKLOADS[0];
  const operations = 180 * Math.pow(50, config.complexity / 100);
  const memory = Math.max(8, operations * Math.exp(-4.9 + .7 * workload.mix[2] + .35 * workload.mix[1]));
  return { operations, memory, parameters: operations * Math.exp(-1.35), mix: workload.mix, sparsity: config.sparsity, workload };
}

export function crossingTime(initial, equilibrium, threshold, tau) {
  if (initial >= threshold) return 0;
  if (equilibrium <= threshold) return Infinity;
  return -tau * Math.log((equilibrium - threshold) / (equilibrium - initial));
}

export function simulate(config) {
  const metrics = metricsFor(config);
  return DEVICES.map(profile => {
    const override = config.overrides[profile.id] ?? {};
    const d = { ...profile, ...override };
    const weightedRate = metrics.mix.reduce((sum, proportion, i) => sum + proportion * d.mix[i], 0);
    const computeSeconds = metrics.operations / d.throughput * weightedRate * (1 - .45 * metrics.sparsity);
    const memorySeconds = metrics.memory / d.bandwidth * (1 + .35 * metrics.mix[2] + .12 * metrics.mix[4]);
    const estimatedDuration = computeSeconds + memorySeconds;
    const computeLoad = Math.min(1, Math.max(.08, .35 + .5 * weightedRate));
    const memoryLoad = Math.min(1, metrics.memory / Math.max(1, estimatedDuration * d.bandwidth));
    const powerScale = override.powerScale ?? 1;
    const power = (d.idle + d.compute * computeLoad + d.memory * memoryLoad) * powerScale;
    const duration = Math.max(estimatedDuration, config.holdSeconds);
    const tau = d.r * d.c;
    const equilibrium = config.ambient + power * d.r;
    const final = temperatureAt(duration, config.ambient, config.initial, power, d.r, d.c);
    const peak = Math.max(config.initial, final);
    const headroom = config.threshold - peak;
    const crossing = crossingTime(config.initial, equilibrium, config.threshold, tau);
    const throttleAt = crossing <= duration ? crossing : null;
    const ratio = duration / tau;
    return { ...d, estimatedDuration, duration, power, energy: power * duration, tau, equilibrium, final, peak, headroom, throttleAt,
      regime: ratio < .3 ? 'transient' : ratio > 2 ? 'saturation' : 'transition',
      thermalSafe: peak < config.threshold, deadlineSafe: duration <= config.deadline,
      enabled: !config.disabled.includes(d.id), initial: config.initial, ambient: config.ambient,
      idlePower: d.idle * powerScale,
    };
  });
}

export function replayTemperature(result, t) {
  if (t <= result.duration) return temperatureAt(t, result.ambient, result.initial, result.power, result.r, result.c);
  return temperatureAt(t - result.duration, result.ambient, result.final, result.idlePower, result.r, result.c);
}

export function schedule(results, config) {
  const policy = POLICIES.find(p => p.id === config.policy) ?? POLICIES[0];
  const enabled = results.filter(d => d.enabled);
  const maxDuration = Math.max(1e-9, ...enabled.map(d => d.duration));
  const maxEnergy = Math.max(1e-9, ...enabled.map(d => d.energy));
  const span = Math.max(1, config.threshold - config.ambient);
  const ranked = results.map(d => {
    const terms = [d.duration / maxDuration, d.energy / maxEnergy, Math.max(0, (d.peak - config.ambient) / span)];
    const contributions = terms.map((term, i) => term * policy.weights[i]);
    const eligible = d.enabled && d.thermalSafe && d.deadlineSafe;
    return { ...d, eligible, terms, contributions, score: contributions.reduce((a, b) => a + b, 0) };
  }).sort((a, b) => a.score - b.score || a.id.localeCompare(b.id));
  const selected = ranked.find(d => d.eligible) ?? null;
  const reasons = selected ? [
    `${selected.headroom.toFixed(1)} °C of peak thermal headroom below the ${config.threshold} °C limit.`,
    `${selected.duration.toFixed(2)} s active execution meets the ${config.deadline} s deadline.`,
    `Lowest weighted cost (${selected.score.toFixed(3)}) among ${ranked.filter(d => d.eligible).length} eligible processors.`,
  ] : [enabled.length ? 'No processor meets both the peak-temperature limit and execution deadline.' : 'All virtual processors are disabled.',
    'Lower the workload, allow more time, or adjust the thermal conditions before dispatch.'];
  return { selected, ranked, policy, reasons, eligibleCount: ranked.filter(d => d.eligible).length };
}

export function trajectoryData(results, sampleCount = 100) {
  const horizon = Math.max(1, ...results.map(d => d.duration)) * 1.12;
  const times = new Set(Array.from({ length: sampleCount + 1 }, (_, i) => horizon * i / sampleCount));
  for (const d of results) {
    times.add(d.duration);
    if (d.throttleAt !== null) times.add(d.throttleAt);
  }
  return [...times].sort((a, b) => a - b).map(t => ({
    time: t, ...Object.fromEntries(results.map(d => [d.id, replayTemperature(d, t)])),
  }));
}
