import { lazy, Suspense, useEffect, useMemo, useRef, useState } from 'react';
import { ArrowDownToLine, ArrowRight, AudioLines, Box, Check, ChevronDown, Cpu, Expand, FlaskConical, Focus, Gauge, Info, Layers3, MoveUpRight, Network, Pause, Play, RotateCcw, ScanLine, ShieldCheck, Snowflake, Thermometer, X, Zap } from 'lucide-react';
import { CartesianGrid, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
const HardwareScene = lazy(() => import('./HardwareScene.jsx'));
import { DEFAULT_CONFIG, DEVICES, POLICIES, WORKLOADS, metricsFor, replayTemperature, schedule, simulate, trajectoryData } from './simulation.mjs';

const format = (n, digits = 1) => Number(n).toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits });
const icons = { scan: ScanLine, network: Network, audio: AudioLines, layers: Layers3 };

function Slider({ label, value, min, max, step = 1, unit = '', onChange, display, hint, id }) {
  const inputId = id ?? label.toLowerCase().replaceAll(' ', '-');
  return <div className="slider-control">
    <div className="control-label"><label htmlFor={inputId}>{label}</label><output htmlFor={inputId}>{display ?? format(value, step < 1 ? 1 : 0)}<span>{unit}</span></output></div>
    <input id={inputId} type="range" min={min} max={max} step={step} value={value} aria-label={label} style={{ '--range-progress': `${(value - min) / (max - min) * 100}%` }} onChange={e => onChange(Number(e.target.value))} />
    {hint && <p className="control-hint">{hint}</p>}
  </div>;
}

function ChartTooltip({ active, payload, label, mode }) {
  if (!active || !payload?.length) return null;
  return <div className="chart-tooltip"><strong>{format(label, 2)} seconds</strong>{payload.map(p => <div key={p.dataKey}><i style={{ background: p.color }} /><span>{DEVICES.find(d => d.id === p.dataKey)?.short}</span><b>{format(p.value)} {mode === 'temperature' ? '°C' : 'J'}</b></div>)}</div>;
}

function MethodDialog({ type, onClose }) {
  const ref = useRef(null);
  useEffect(() => { if (type && !ref.current.open) ref.current.showModal(); }, [type]);
  return <dialog ref={ref} className="method-dialog" onClose={onClose} onClick={e => { if (e.target === ref.current) onClose(); }}>
    <div className="dialog-content"><button className="icon-button dialog-close" onClick={onClose} aria-label="Close explanation"><X size={20} /></button>
      <div className="eyebrow"><FlaskConical size={14} /> THE SCIENCE, NOT THE SPECULATION</div>
      <h2>{type === 'project' ? 'Built for exploration.' : 'One model. Clear assumptions.'}</h2>
      {type === 'project' && <><p className="dialog-lead">Adaptive Thermal-Aware Code Scheduler for Edge AI Devices Using Static Software Metrics.</p><p>A hardware-free university research prototype for investigating how software structure and starting thermal state influence processor selection. Inspect the carrier, change the experiment, and compare the scheduler’s choices.</p></>}
      <h3>First-order RC thermal response</h3>
      <div className="formula">T(t) = Tₐ + (T₀ − Tₐ)e<sup>−t/(RC)</sup> + PR(1 − e<sup>−t/(RC)</sup>)</div>
      <p>Each processor is an independent lumped thermal package with constant active power P, thermal resistance R (K/W), and capacitance C (J/K). Its time constant is τ = RC. The response is monotonic during active execution, so <strong>peak temperature = max(T₀, T_end)</strong>. A hot package can cool while computing when PR &lt; T₀ − Tₐ.</p>
      <h3>From static metrics to runtime</h3>
      <p>Operation count O ranges log-uniformly from 180 to 9,000 million as complexity increases. Operator proportions, memory footprint and sparsity determine runtime using the study’s deterministic plant:</p>
      <div className="formula formula-small">t̂ = (O / Q) · Σ(sᵢmᵢ) · (1 − 0.45z) + (M / B) · (1 + 0.35s_att + 0.12s_norm)</div>
      <p>Q is virtual throughput, B is bandwidth, z is sparsity, and mᵢ is the device-specific operator cost. Active power combines idle, compute-utilization and memory-utilization terms. Energy is P × active duration. A nonzero execution window models repeated, continuously active inference for at least that duration; it cannot shorten a single inference.</p>
      <h3>Explainable scheduling</h3>
      <p>The scheduler first excludes disabled processors, any processor whose predicted peak reaches the temperature limit, and any processor that misses the execution deadline. It then minimizes a weighted sum of normalized duration, energy and peak elevation. Adaptive weights are 30% latency, 35% energy and 35% thermal elevation. If no processor is eligible, <strong>dispatch is refused</strong> rather than silently choosing unsafe hardware.</p>
      <div className="method-warning"><Info size={18} /><div><strong>Virtual estimates. Not hardware measurements.</strong><p>The Pi-inspired carrier is illustrative: it does not claim Raspberry Pi specifications or built-in NPU/DSP hardware. CPU core selection is visual inspection; temperatures are package-level, not independently modelled per core. No trained ML predictor is loaded. Thermal coupling, DVFS, real instruction compilation and throttling feedback are not modelled. A predicted threshold crossing is a risk indicator, not simulated clock reduction.</p></div></div>
      <p className="method-footnote">Counterfactual curves run each candidate independently at the same initial state. Curves transition to idle power after active completion. The execution timeline animates only the chosen dispatch; other bars are alternative estimates. Virtual profiles are taken from the existing simulation study without its stochastic noise.</p>
      <button className="button primary" onClick={onClose}>Back to the experiment <ArrowRight size={17} /></button>
    </div>
  </dialog>;
}

export default function App() {
  const [config, setConfig] = useState(() => ({ ...DEFAULT_CONFIG, overrides: {}, disabled: [] }));
  const [selectedId, setSelectedId] = useState('cpu');
  const [selectedCore, setSelectedCore] = useState(null);
  const [thermalView, setThermalView] = useState(true);
  const [exploded, setExploded] = useState(false);
  const [view, setView] = useState('perspective');
  const [resetKey, setResetKey] = useState(0);
  const [inspectorOpen, setInspectorOpen] = useState(false);
  const [status, setStatus] = useState('idle');
  const [elapsed, setElapsed] = useState(0);
  const [speed, setSpeed] = useState(4);
  const [chartMode, setChartMode] = useState('temperature');
  const [visible, setVisible] = useState(DEVICES.map(d => d.id));
  const [dialog, setDialog] = useState(null);
  const [toast, setToast] = useState('');
  const results = useMemo(() => simulate(config), [config]);
  const decision = useMemo(() => schedule(results, config), [results, config]);
  const metrics = useMemo(() => metricsFor(config), [config]);
  const selected = results.find(d => d.id === selectedId);
  const chosen = decision.selected;
  const duration = chosen?.duration ?? 0;
  const progress = duration ? Math.min(1, elapsed / duration) : 0;
  const temperatures = Object.fromEntries(results.map(d => [d.id, status === 'idle' ? d.final : replayTemperature(d, elapsed)]));
  const chartData = useMemo(() => trajectoryData(results).map(row => chartMode === 'temperature' ? row : { time: row.time, ...Object.fromEntries(results.map(d => [d.id, Math.min(row.time, d.duration) * d.power])) }), [results, chartMode]);
  const chartValues = chartData.flatMap(row => visible.map(id => row[id]));
  const yDomain = chartMode === 'temperature' ? [Math.floor(Math.min(...chartValues) - 2), Math.ceil(Math.max(...chartValues) + 2)] : [0, Math.ceil(Math.max(...chartValues) * 1.1)];

  useEffect(() => { setElapsed(0); setStatus('idle'); }, [config]);
  useEffect(() => {
    if (status !== 'running' || !duration) return;
    let previous = performance.now();
    const handle = setInterval(() => {
      const now = performance.now();
      const dt = (now - previous) / 1000 * speed;
      previous = now;
      setElapsed(old => Math.min(duration, old + dt));
    }, 50);
    return () => clearInterval(handle);
  }, [status, duration, speed]);
  useEffect(() => { if (status === 'running' && elapsed >= duration) setStatus('complete'); }, [elapsed, duration, status]);
  useEffect(() => { if (!toast) return; const timer = setTimeout(() => setToast(''), 3200); return () => clearTimeout(timer); }, [toast]);

  const update = (key, value) => setConfig(old => ({ ...old, [key]: value }));
  const selectComponent = (id, core = null) => { setSelectedId(id); setSelectedCore(core); };
  const editPlant = (key, value) => setConfig(old => ({ ...old, overrides: { ...old.overrides, [selectedId]: { ...old.overrides[selectedId], [key]: value } } }));
  const run = () => {
    if (!chosen) return;
    if (status === 'running') { setStatus('paused'); return; }
    if (status !== 'paused') setElapsed(0);
    setSelectedId(chosen.id); setSelectedCore(null); setStatus('running');
  };
  const reset = () => { setConfig({ ...DEFAULT_CONFIG, overrides: {}, disabled: [] }); setSelectedId('cpu'); setSelectedCore(null); setElapsed(0); setStatus('idle'); setResetKey(k => k + 1); setView('perspective'); setExploded(false); setToast('Experiment reset to the reference configuration.'); };
  const exportRun = () => {
    const snapshot = { project: 'Adaptive Thermal-Aware Code Scheduler for Edge AI Devices Using Static Software Metrics', provenance: 'Deterministic virtual hardware estimates. Not physical measurements. Independent first-order RC packages; no DVFS or shared thermal coupling.', createdAt: new Date().toISOString(), config, metrics, results, decision, playback: { status, elapsed, speed } };
    const url = URL.createObjectURL(new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' }));
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = 'therm-experiment.json'; anchor.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); setToast('Experiment exported as a reproducible JSON snapshot.');
  };
  const toggleLine = id => setVisible(old => old.includes(id) ? old.length === 1 ? old : old.filter(x => x !== id) : [...old, id]);
  const statusText = !chosen ? 'NO SAFE DISPATCH' : status === 'running' ? 'SIMULATION RUNNING' : status === 'paused' ? 'SIMULATION PAUSED' : status === 'complete' ? 'EXECUTION COMPLETE' : 'EXPERIMENT READY';

  return <div className="app-shell">
    <header className="site-header">
      <a className="brand" href="#top" aria-label="Therm studio home"><span className="brand-mark"><span /><span /><span /></span><strong>THERM<span>®</span></strong><i /><span className="brand-caption">EDGE SIMULATION<br />STUDIO</span></a>
      <nav aria-label="Main navigation"><a href="#experiment" className="nav-active">The simulator</a><button onClick={() => setDialog('method')}>Model & method <MoveUpRight size={12} /></button><button onClick={() => setDialog('project')}>The project</button></nav>
      <button className="button export-button" onClick={exportRun}><ArrowDownToLine size={15} /><span>Export experiment</span></button>
    </header>

    <main id="top">
      <section className="intro">
        <div><p className="eyebrow"><span className="small-line" /> THERMAL INTELLIGENCE / VOL. 01</p><h1>Performance, <em>in balance.</em></h1><p className="intro-description">Explore the relationship between code, power and heat.<br className="desktop-break" /> A living experiment in adaptive edge-AI scheduling.</p></div>
        <div className="intro-meta"><div className="prototype-badge"><FlaskConical size={14} /> RESEARCH PROTOTYPE</div><p>Virtual hardware. Real calculations.<br />No physical device required.</p><span className="meta-version">RC MODEL <i /> DETERMINISTIC V1.0</span></div>
      </section>

      <div className="experiment-layout" id="experiment">
        <aside className="control-panel" aria-label="Simulation controls">
          <div className="panel-heading"><div><span className="eyebrow">DESIGN YOUR SCENARIO</span><h2>The experiment.</h2></div><button className="icon-button light" onClick={reset} aria-label="Reset experiment" title="Reset experiment"><RotateCcw size={17} /></button></div>
          <section className="control-section"><div className="section-label"><span>01</span> THERMAL ENVIRONMENT <Thermometer size={14} /></div>
            <Slider label="Ambient temperature" value={config.ambient} min={10} max={50} unit="°C" onChange={v => update('ambient', v)} />
            <Slider label="Initial chip temperature" value={config.initial} min={20} max={95} unit="°C" onChange={v => update('initial', v)} />
            <Slider label="Thermal limit" value={config.threshold} min={45} max={95} unit="°C" onChange={v => update('threshold', v)} />
          </section>
          <section className="control-section"><div className="section-label"><span>02</span> THE WORKLOAD <Layers3 size={14} /></div>
            <div className="workload-options">{WORKLOADS.map(w => { const Icon = icons[w.icon]; return <button key={w.id} className={config.workload === w.id ? 'workload-button selected' : 'workload-button'} aria-pressed={config.workload === w.id} onClick={() => setConfig(old => ({ ...old, workload: w.id, sparsity: w.sparsity }))}><Icon size={18} /><span>{w.name}</span>{config.workload === w.id && <i />}</button>; })}</div>
            <Slider label="Task complexity" value={config.complexity} min={0} max={100} unit="%" onChange={v => update('complexity', v)} />
            <Slider label="Operator sparsity" value={config.sparsity} min={0} max={.95} step={.05} display={format(config.sparsity * 100, 0)} unit="%" onChange={v => update('sparsity', v)} />
            <div className="static-metrics"><span><b>{format(metrics.operations / 1000, 2)}</b> GOPs</span><span><b>{format(metrics.memory)}</b> MB</span><span className="metrics-note">STATIC PROFILE</span></div>
          </section>
          <section className="control-section"><div className="section-label"><span>03</span> EXECUTION RULES <Gauge size={14} /></div>
            <Slider label="Execution window" value={config.holdSeconds} min={0} max={180} step={5} display={config.holdSeconds ? format(config.holdSeconds, 0) : 'Auto'} unit={config.holdSeconds ? 's min' : ''} hint="Auto: one inference. Longer windows sustain active computation." onChange={v => update('holdSeconds', v)} />
            <Slider label="Execution deadline" value={config.deadline} min={10} max={240} step={5} unit="s" onChange={v => update('deadline', v)} />
            <div className="policy-heading">Scheduling objective</div><div className="policy-options">{POLICIES.map(p => <button key={p.id} className={config.policy === p.id ? 'selected' : ''} aria-pressed={config.policy === p.id} onClick={() => update('policy', p.id)}>{p.name}</button>)}</div>
          </section>
          <div className="run-area"><div className={`run-status ${!chosen ? 'warning' : ''}`}><i className={status === 'running' ? 'pulse-dot' : ''} /><span>{statusText}</span></div><button className="button run-button" onClick={run} disabled={!chosen}>{status === 'running' ? <Pause size={17} /> : <Play size={17} fill="currentColor" />}<span>{status === 'running' ? 'Pause simulation' : status === 'paused' ? 'Resume simulation' : status === 'complete' ? 'Run again' : 'Run simulation'}</span><ArrowRight size={17} /></button><p><ShieldCheck size={12} /> Safety constraints are enforced before dispatch.</p></div>
        </aside>

        <div className="studio-content">
          <section className={`hardware-stage ${thermalView ? 'thermal-mode' : ''}`} aria-label="Interactive 3D virtual hardware">
            <div className="stage-top"><div className="stage-label"><span className="live-dot" /> THE VIRTUAL BENCH <span className="stage-sub">/ 3D INTERACTIVE</span></div><div className="stage-switch" aria-label="Hardware visualization"><button className={!thermalView ? 'active' : ''} onClick={() => setThermalView(false)} aria-pressed={!thermalView}><Box size={13} /> Hardware</button><button className={thermalView ? 'active' : ''} onClick={() => setThermalView(true)} aria-pressed={thermalView}><Thermometer size={13} /> Thermal</button></div></div>
            <div className="stage-editorial"><h2>Code meets<br /><em>its physical limits.</em></h2><p>Select a processor.<br />See the invisible.</p></div>
            <div className="scene-container"><Suspense fallback={<div className="scene-loading"><Cpu size={28} /><span>Preparing the virtual bench</span></div>}><HardwareScene selectedId={selectedId} selectedCore={selectedCore} onSelect={selectComponent} temperatures={temperatures} activeId={chosen?.id} running={status === 'running'} progress={progress} thermalView={thermalView} exploded={exploded} view={view} resetKey={resetKey} /></Suspense></div>
            <div className="stage-corner top-right"><span className="tiny-label">{status === 'idle' ? 'FORECAST PREVIEW' : status === 'running' ? 'DISPATCH REPLAY' : status.toUpperCase()}</span><span className="stage-time">{status === 'idle' ? 'T_end' : `${format(elapsed, 2)} s`}</span></div>
            <div className="component-inspector"><div className="inspector-top"><span className="chip-icon"><Cpu size={17} /></span><div><span className="tiny-label">{selectedCore === null ? 'SELECTED COMPONENT' : `CORE ${String(selectedCore + 1).padStart(2, '0')} · PACKAGE TEMP`}</span><h3>{selected.name}</h3></div><button className={`icon-button ${inspectorOpen ? 'active' : ''}`} aria-label="Edit selected processor parameters" aria-expanded={inspectorOpen} onClick={() => setInspectorOpen(v => !v)}><ChevronDown size={17} /></button></div>
              <div className="inspector-reading"><strong>{format(temperatures[selectedId])}<span>°C</span></strong><span className={selected.final < config.initial ? 'cooling-badge' : 'heating-badge'}>{selected.final < config.initial ? <Snowflake size={11} /> : <Thermometer size={11} />}{selected.final < config.initial ? 'Net cooling' : 'Net heating'}</span></div>
              <div className="inspector-specs"><span><b>{format(selected.power, 2)}</b> W active</span><span>τ <b>{format(selected.tau)}</b> s</span></div>
              {inspectorOpen && <div className="plant-controls"><p>Virtual package parameters</p><Slider label="Thermal resistance" id="plant-resistance" value={selected.r} min={1} max={8} step={.1} unit="K/W" onChange={v => editPlant('r', v)} /><Slider label="Thermal capacitance" id="plant-capacitance" value={selected.c} min={8} max={60} unit="J/K" onChange={v => editPlant('c', v)} /><Slider label="Reference throughput" id="plant-throughput" value={selected.throughput} min={20} max={500} unit="Mops/s" onChange={v => editPlant('throughput', v)} /><Slider label="Power multiplier" id="plant-power" value={config.overrides[selectedId]?.powerScale ?? 1} min={.3} max={2} step={.1} unit="×" onChange={v => editPlant('powerScale', v)} /><button className="availability-button" aria-pressed={selected.enabled} onClick={() => update('disabled', selected.enabled ? [...config.disabled, selectedId] : config.disabled.filter(id => id !== selectedId))}>{selected.enabled ? <Check size={13} /> : <X size={13} />}{selected.enabled ? 'Available to scheduler' : 'Excluded from scheduler'}</button></div>}
            </div>
            <div className="stage-bottom"><div className="carrier-caption"><span>PI-CLASS / HETEROGENEOUS CARRIER</span><p>Illustrative hardware · independent thermal packages</p></div><div className="scene-tools"><button aria-label="Reset camera" title="Reset camera" onClick={() => setResetKey(k => k + 1)}><Focus size={16} /></button><button aria-label="Toggle top view" title="Top view" aria-pressed={view === 'top'} className={view === 'top' ? 'active' : ''} onClick={() => setView(v => v === 'top' ? 'perspective' : 'top')}><Box size={16} /></button><button aria-label="Explode components" title="Exploded inspection" aria-pressed={exploded} className={exploded ? 'active' : ''} onClick={() => setExploded(v => !v)}><Expand size={16} /></button></div></div>
          </section>
          <div className="scene-utility"><span className="orbit-hint"><RotateCcw size={12} /> Drag to orbit <i /> Scroll to zoom <i /> Click to inspect</span><div className="thermal-scale"><span>32°</span><i /><span>103°C</span><button aria-label="Explain thermal visualization" onClick={() => setDialog('method')}><Info size={12} /></button></div></div>
          <div className="processor-selector" role="group" aria-label="Accessible component selection">{DEVICES.map(d => <button key={d.id} aria-pressed={selectedId === d.id} className={selectedId === d.id ? 'selected' : ''} onClick={() => selectComponent(d.id)}><i style={{ background: d.color }} />{d.short}{chosen?.id === d.id && <span className="scheduled-tick"><Check size={10} /></span>}</button>)}{selectedId === 'cpu' && <div className="core-selector" aria-label="CPU core inspection">{[0, 1, 2, 3].map(core => <button key={core} aria-label={`Inspect CPU core ${core + 1}`} aria-pressed={selectedCore === core} className={selectedCore === core ? 'selected' : ''} onClick={() => selectComponent('cpu', core)}>{core + 1}</button>)}</div>}<span className="selector-caption">INSPECT A COMPONENT</span></div>

          <div className="analysis-grid">
            <section className="chart-panel"><div className="analysis-heading"><div><span className="eyebrow">01 / OBSERVE</span><h2>{chartMode === 'temperature' ? 'Thermal trajectories' : 'Active energy'}</h2></div><div className="mini-tabs"><button className={chartMode === 'temperature' ? 'active' : ''} onClick={() => setChartMode('temperature')} aria-label="Show temperature chart" aria-pressed={chartMode === 'temperature'}><Thermometer size={14} /></button><button className={chartMode === 'energy' ? 'active' : ''} onClick={() => setChartMode('energy')} aria-label="Show energy chart" aria-pressed={chartMode === 'energy'}><Zap size={14} /></button></div></div>
              <div className="chart-note"><span>{chartMode === 'temperature' ? 'Independent counterfactuals · active → idle' : 'Accumulated active energy · idle excluded'}</span><span>{chartMode === 'temperature' ? `Limit ${config.threshold} °C` : 'E = P × t'}</span></div>
              <div className="live-chart"><ResponsiveContainer width="100%" height="100%" minWidth={0}><LineChart data={chartData} margin={{ top: 12, right: 12, left: -24, bottom: 4 }}><CartesianGrid stroke="#493b50" strokeDasharray="2 6" vertical={false} /><XAxis dataKey="time" type="number" domain={[0, 'dataMax']} tickFormatter={v => `${format(v, 0)}s`} tick={{ fill: '#9d919f', fontSize: 10 }} tickLine={false} axisLine={false} minTickGap={24} /><YAxis domain={yDomain} tickFormatter={v => `${format(v, 0)}${chartMode === 'temperature' ? '°' : ''}`} tick={{ fill: '#9d919f', fontSize: 10 }} tickLine={false} axisLine={false} tickCount={5} /><Tooltip content={<ChartTooltip mode={chartMode} />} cursor={{ stroke: '#bfa5c7', strokeDasharray: '3 3' }} />{chartMode === 'temperature' && config.threshold >= yDomain[0] && config.threshold <= yDomain[1] && <ReferenceLine y={config.threshold} stroke="#f0997a" strokeDasharray="4 4" />}{status !== 'idle' && <ReferenceLine x={elapsed} stroke="#f1c56b" strokeDasharray="4 4" />}{DEVICES.filter(d => visible.includes(d.id)).map(d => <Line key={d.id} name={d.short} type="monotone" dataKey={d.id} stroke={d.color} strokeWidth={chosen?.id === d.id ? 2.8 : 1.5} strokeOpacity={chosen?.id === d.id ? 1 : .7} dot={false} isAnimationActive={false} />)}</LineChart></ResponsiveContainer></div>
              <div className="chart-legend">{DEVICES.map(d => <button key={d.id} aria-pressed={visible.includes(d.id)} className={!visible.includes(d.id) ? 'muted' : ''} onClick={() => toggleLine(d.id)}><i style={{ background: d.color }} />{d.short}</button>)}</div>
            </section>
            <section className={`decision-panel ${!chosen ? 'no-dispatch' : ''}`} aria-label="Scheduler decision"><div className="analysis-heading"><span className="eyebrow">02 / DECIDE</span><span className="decision-label">{decision.policy.name.toUpperCase()} SCHEDULER</span></div><div className="decision-title"><h2>{chosen ? 'The right processor.' : 'Safety comes first.'}</h2><p>{chosen ? 'For this moment.' : 'No eligible processor.'}</p></div><div className="chosen-processor"><span>{chosen?.short ?? '—'}</span><div>{chosen ? <><span className="recommendation"><Check size={12} /> RECOMMENDED</span><p>{decision.eligibleCount} / 5 eligible</p></> : <span className="recommendation blocked"><ShieldCheck size={12} /> DISPATCH BLOCKED</span>}</div></div>
              {chosen && <div className="decision-metrics"><div><span>{format(chosen.duration, 2)}<small>s</small></span><p>execution</p></div><div><span>{format(chosen.energy)}<small>J</small></span><p>energy</p></div><div><span>{format(chosen.headroom)}<small>°C</small></span><p>headroom</p></div></div>}
              <div className="decision-reason">{chosen ? <><ShieldCheck size={17} /><p>Thermally safe. Within deadline.<br /><strong>Lowest combined scheduling cost.</strong></p></> : <><Info size={17} /><p>{decision.reasons[0]}</p></>}</div>
              <details className="decision-details"><summary>Why this choice?<ChevronDown size={13} /></summary><ul>{decision.reasons.map(reason => <li key={reason}>{reason}</li>)}</ul>{chosen && <div className="score-breakdown">{['Latency', 'Energy', 'Thermal'].map((name, i) => <div key={name}><span>{name} · {decision.policy.weights[i] * 100}%</span><i><b style={{ width: `${Math.min(100, chosen.terms[i] * 100)}%` }} /></i><span>{format(chosen.contributions[i], 3)}</span></div>)}</div>}<p className="cost-note">Feasibility first, then normalized weighted cost. No ML predictor or physical measurement.</p></details>
            </section>
          </div>
        </div>
      </div>

      <section className="timeline-panel" id="execution"><div className="wide-section-heading"><div><span className="eyebrow">03 / DISPATCH</span><h2>A plan for every processor.</h2><p>One chosen execution. Four counterfactual alternatives.</p></div><div className="playback-controls"><span className="time-readout">{format(elapsed, 2)} <small>/ {format(duration, 2)} s</small></span><div className="speed-buttons" role="group" aria-label="Playback speed">{[1, 4, 10].map(s => <button key={s} className={speed === s ? 'active' : ''} aria-pressed={speed === s} onClick={() => setSpeed(s)}>{s}×</button>)}</div><button className="icon-button" aria-label="Restart playback" disabled={!chosen} onClick={() => { setElapsed(0); setStatus('idle'); }}><RotateCcw size={16} /></button></div></div>
        <div className="timeline-ruler"><span>PROCESSOR</span><div>{[0, .25, .5, .75, 1].map(f => <span key={f}>{format(Math.max(...results.map(d => d.duration)) * f, 0)}s</span>)}</div><span>EST. DURATION</span></div>
        <div className="timeline-lanes">{results.map(d => { const active = chosen?.id === d.id; const width = d.duration / Math.max(...results.map(x => x.duration)) * 100; return <div className={`timeline-lane ${active ? 'scheduled' : ''} ${!d.enabled ? 'disabled' : ''}`} key={d.id}><button onClick={() => selectComponent(d.id)}><span className="lane-dot" style={{ background: d.color }} /><span>{d.short}</span>{active && <ArrowRight size={12} />}</button><div className="lane-track"><div className="lane-bar" style={{ width: `${width}%`, '--lane-color': d.color }}><div className="lane-fill" style={{ width: `${active ? progress * 100 : 0}%` }} />{width > 17 && <span>{active ? status === 'complete' ? 'EXECUTION COMPLETE' : status === 'running' ? 'EXECUTING' : status === 'paused' ? 'PAUSED' : 'SCHEDULED' : 'VIRTUAL ESTIMATE'}</span>}{active && progress > 0 && progress < 1 && <i className="timeline-playhead" style={{ left: `${progress * 100}%` }} />}</div></div><span className="lane-duration">{format(d.duration, 2)}<small> s</small></span></div>; })}</div>
        <div className="timeline-footer"><span><i className="gold-dot" /> Scheduled execution</span><span><i className="hollow-dot" /> Alternative estimate</span><p><Info size={12} /> Playback speed changes animation only, not the physical calculations.</p></div>
      </section>

      <section className="comparison-panel"><div className="wide-section-heading"><div><span className="eyebrow">04 / COMPARE</span><h2>Different silicon. Different trade-offs.</h2></div><button className="text-button" onClick={() => setDialog('method')}>Understand the model <MoveUpRight size={13} /></button></div><div className="table-scroll"><table className="comparison-table"><thead><tr><th>Virtual processor</th><th>Execution time</th><th>Active energy</th><th>End temperature</th><th>Peak temperature</th><th>Peak headroom</th><th>Threshold crossing</th></tr></thead><tbody>{results.map(d => <tr key={d.id} className={chosen?.id === d.id ? 'recommended-row' : ''}><td><button className="table-device" onClick={() => selectComponent(d.id)}><span className="table-chip"><Cpu size={15} /></span><span><strong>{d.name}</strong><small>{!d.enabled ? 'Excluded' : !d.thermalSafe ? 'Thermal limit reached' : !d.deadlineSafe ? 'Deadline exceeded' : d.regime}</small></span>{chosen?.id === d.id && <span className="table-chosen"><Check size={12} /></span>}</button></td><td>{format(d.duration, 2)}<small> s</small></td><td>{format(d.energy)}<small> J</small></td><td>{format(d.final)}<small> °C</small><span className={`temp-direction ${d.final < config.initial ? 'down' : 'up'}`}>{d.final < config.initial ? '↘' : '↗'}</span></td><td>{format(d.peak)}<small> °C</small></td><td className={d.headroom <= 0 ? 'danger-text' : ''}>{format(d.headroom)}<small> °C</small></td><td>{d.throttleAt === null ? <span className="risk-safe"><i /> Not predicted</span> : <span className="danger-text">{d.throttleAt === 0 ? 'At start' : `${format(d.throttleAt, 2)} s`}<small> · risk</small></span>}</td></tr>)}</tbody></table></div><div className="comparison-footnote"><Info size={13} /><p>Peak temperature includes the initial state. Crossing the limit predicts throttling risk; no clock-frequency feedback is simulated. Energy covers active execution, not the entire device system.</p></div></section>
    </main>
    <footer className="site-footer"><div className="footer-brand"><span className="brand-mark small"><span /><span /><span /></span><strong>THERM</strong><p>Intelligence with a thermal conscience.</p></div><div className="footer-project"><p>Adaptive Thermal-Aware Code Scheduler for Edge AI Devices<br />Using Static Software Metrics</p><span>UNIVERSITY RESEARCH PROTOTYPE <i /> SIMULATION, NOT MEASUREMENT</span></div><button className="footer-top" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} aria-label="Back to top"><MoveUpRight size={18} /></button></footer>
    {toast && <div className="toast" role="status"><Check size={16} />{toast}</div>}
    {dialog && <MethodDialog type={dialog} onClose={() => setDialog(null)} />}
  </div>;
}

