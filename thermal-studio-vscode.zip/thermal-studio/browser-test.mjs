import { chromium, expect } from '@playwright/test';
import { PerspectiveCamera, Vector3 } from 'three';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { DEFAULT_CONFIG, schedule, simulate } from './src/simulation.mjs';

const browser = await chromium.launch({ channel: 'msedge', headless: true, args: ['--enable-unsafe-swiftshader', '--use-angle=swiftshader'] });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, reducedMotion: 'reduce', acceptDownloads: true });
const page = await context.newPage();
const errors = [], checks = [];
page.on('pageerror', e => errors.push(e.message));
const check = name => { checks.push(name); console.log(`PASS: ${name}`); };
const setRange = async (name, value) => {
  await page.getByRole('slider', { name, exact: true }).evaluate((input, next) => {
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(input, next);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }, String(value));
};
const selectedShort = () => page.locator('.chosen-processor > span');
const reset = () => page.getByRole('button', { name: 'Reset experiment', exact: true }).click();
const hash = data => createHash('sha256').update(data).digest('hex');

try {
  await page.goto('http://127.0.0.1:5173', { waitUntil: 'networkidle', timeout: 120000 });
  await expect(page.locator('h1')).toHaveText('Performance, in balance.');
  await expect(page.locator('canvas')).toBeVisible({ timeout: 30000 });
  await expect(page.locator('.scene-container').getByText(/^CPU\d+°C$/)).toBeVisible({ timeout: 30000 });
  const webgl = await page.locator('canvas').evaluate(canvas => {
    const gl = canvas.getContext('webgl2');
    return { available: !!gl, lost: gl?.isContextLost(), width: canvas.width, height: canvas.height };
  });
  expect(webgl.available).toBe(true); expect(webgl.lost).toBe(false);
  await expect(selectedShort()).toHaveText(schedule(simulate(DEFAULT_CONFIG), DEFAULT_CONFIG).selected.short);
  await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), { timeout: 10000 }).toBe(true);
  check('Desktop renders a real WebGL carrier, all comparison outputs, and no page overflow');
  await page.screenshot({ path: 'test-artifacts/desktop.png', fullPage: true });

  const canvas = page.locator('canvas');
  const rect = await canvas.boundingBox();
  const camera = new PerspectiveCamera(39, rect.width / rect.height, .1, 100);
  camera.position.set(7, 8, 9); camera.lookAt(0, .25, 0); camera.updateMatrixWorld();
  const corePoint = new Vector3(-.87 - .328, .18 + .229, .18 - .313).project(camera);
  await page.mouse.click(rect.x + (corePoint.x + 1) / 2 * rect.width, rect.y + (1 - corePoint.y) / 2 * rect.height);
  await expect(page.locator('.inspector-top .tiny-label')).toContainText('CORE 01', { timeout: 10000 });
  check('Selecting a CPU core directly on the 3D mesh updates the package inspector');
  const beforeOrbit = hash(await canvas.screenshot());
  const orbitRect = await canvas.boundingBox();
  await page.mouse.move(orbitRect.x + orbitRect.width * .52, orbitRect.y + orbitRect.height * .55);
  await page.mouse.down();
  await page.mouse.move(orbitRect.x + orbitRect.width * .64, orbitRect.y + orbitRect.height * .62, { steps: 12 });
  await page.mouse.up();
  await page.mouse.wheel(0, -220);
  await expect.poll(async () => hash(await canvas.screenshot()), { timeout: 15000 }).not.toBe(beforeOrbit);
  check('Orbit and zoom change the rendered 3D view');
  await page.getByRole('button', { name: 'Toggle top view', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Toggle top view', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await page.getByRole('button', { name: 'Explode components', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Explode components', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await page.getByRole('button', { name: 'Hardware', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Hardware', exact: true })).toHaveAttribute('aria-pressed', 'true');
  check('Top view, exploded inspection and metallic hardware mode are interactive');
  await page.locator('.stage-switch').getByRole('button', { name: 'Thermal', exact: true }).click();
  await page.getByRole('button', { name: 'Explode components', exact: true }).click();
  await page.getByRole('button', { name: 'Toggle top view', exact: true }).click();

  await page.getByRole('button', { name: 'Latency', exact: true }).click();
  const latency = { ...DEFAULT_CONFIG, policy: 'latency' };
  await expect(selectedShort()).toHaveText(schedule(simulate(latency), latency).selected.short);
  check('Changing the objective recomputes the processor selection');
  await setRange('Task complexity', 100);
  await expect(page.locator('.static-metrics')).toContainText('9.00');
  await page.getByRole('button', { name: 'Transformer', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Transformer', exact: true })).toHaveAttribute('aria-pressed', 'true');
  check('Workload, complexity and static descriptors update');
  await reset();
  await setRange('Initial chip temperature', 90);
  await expect(page.getByRole('button', { name: 'Run simulation', exact: true })).toBeDisabled();
  await expect(page.locator('.recommendation.blocked')).toContainText('DISPATCH BLOCKED');
  expect(await page.locator('.comparison-table').getByText('At start', { exact: false }).count()).toBe(5);
  check('Initially overheated devices trigger a real unsafe-dispatch refusal');
  await reset();
  await setRange('Execution window', 180);
  await setRange('Execution deadline', 10);
  await expect(page.getByRole('button', { name: 'Run simulation', exact: true })).toBeDisabled();
  await expect(page.locator('.comparison-table')).toContainText('180.00');
  check('Sustained duration and deadline controls enforce execution feasibility');
  await reset();

  await page.getByRole('button', { name: '1×', exact: true }).click();
  await page.getByRole('button', { name: 'Run simulation', exact: true }).click();
  await expect(page.locator('.run-status')).toContainText('SIMULATION RUNNING');
  await expect.poll(async () => parseFloat(await page.locator('.time-readout').innerText())).toBeGreaterThan(0);
  await page.getByRole('button', { name: 'Pause simulation', exact: true }).click();
  await expect(page.locator('.run-status')).toContainText('SIMULATION PAUSED');
  const pausedTime = await page.locator('.time-readout').innerText();
  await expect(page.locator('.time-readout')).toHaveText(pausedTime);
  await page.getByRole('button', { name: '10×', exact: true }).click();
  await page.getByRole('button', { name: 'Resume simulation', exact: true }).click();
  await expect(page.locator('.run-status')).toContainText('EXECUTION COMPLETE', { timeout: 20000 });
  await expect(page.locator('.timeline-lane.scheduled .lane-fill')).toHaveAttribute('style', 'width: 100%;');
  check('Run, pause, resume, accelerated replay and task completion work');

  await page.getByRole('button', { name: 'Edit selected processor parameters', exact: true }).click();
  await setRange('Thermal resistance', 5.5);
  await expect(page.locator('.inspector-specs')).toContainText('104.5');
  await page.getByRole('button', { name: 'Available to scheduler', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Excluded from scheduler', exact: true })).toBeVisible();
  await expect(selectedShort()).not.toHaveText('NPU');
  check('Editing RC parameters and excluding a selected processor changes the schedule');
  await reset();
  await page.getByRole('button', { name: 'Edit selected processor parameters', exact: true }).click();
  await page.getByRole('button', { name: 'Show energy chart', exact: true }).click();
  await expect(page.locator('.analysis-heading').getByRole('heading', { name: 'Active energy', exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Show temperature chart', exact: true }).click();
  await page.locator('.chart-legend button').first().click();
  await expect(page.locator('.chart-legend button').first()).toHaveAttribute('aria-pressed', 'false');
  check('Energy/temperature chart switching and series visibility work');

  await page.getByRole('button', { name: 'Model & method', exact: false }).click();
  await expect(page.locator('dialog')).toBeVisible();
  await expect(page.locator('dialog')).toContainText('No trained ML predictor is loaded');
  await page.getByRole('button', { name: 'Close explanation', exact: true }).click();
  await expect(page.locator('dialog')).toHaveCount(0);
  check('Scientific assumptions and limitations are accessible in a working modal');
  const downloadEvent = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Export experiment', exact: true }).click();
  const download = await downloadEvent;
  await download.saveAs('test-artifacts/experiment.json');
  const snapshot = JSON.parse(await readFile('test-artifacts/experiment.json', 'utf8'));
  expect(snapshot.results).toHaveLength(5); expect(snapshot.provenance).toContain('Not physical measurements');
  expect(snapshot.decision.selected.id).toBe(schedule(simulate(DEFAULT_CONFIG), DEFAULT_CONFIG).selected.id);
  check('JSON export contains reproducible configuration, calculated results and provenance');

  await page.setViewportSize({ width: 390, height: 844 });
  await expect(page.locator('canvas')).toBeVisible();
  await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), { timeout: 10000 }).toBe(true);
  await page.screenshot({ path: 'test-artifacts/mobile.png', fullPage: true });
  await page.getByRole('button', { name: 'Run simulation', exact: true }).click();
  await expect(page.locator('.run-status')).toContainText('EXECUTION COMPLETE', { timeout: 20000 });
  check('390px mobile layout has no horizontal overflow and supports simulation');

  const fallbackContext = await browser.newContext({ viewport: { width: 1200, height: 900 } });
  await fallbackContext.addInitScript(() => {
    const getContext = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function(kind, ...args) {
      return kind === 'webgl2' ? null : getContext.call(this, kind, ...args);
    };
  });
  const fallbackPage = await fallbackContext.newPage();
  await fallbackPage.bringToFront();
  await fallbackPage.goto('http://127.0.0.1:5173', { waitUntil: 'networkidle', timeout: 60000 });
  await expect(fallbackPage.getByText('3D hardware view unavailable', { exact: true })).toBeVisible({ timeout: 30000 });
  await fallbackPage.locator('.processor-selector').getByRole('button', { name: 'DSP', exact: false }).click();
  await expect(fallbackPage.locator('.inspector-top h3')).toHaveText('Embedded DSP');
  await fallbackPage.getByRole('button', { name: '10×', exact: true }).click();
  await fallbackPage.getByRole('button', { name: 'Run simulation', exact: true }).click();
  await expect(fallbackPage.locator('.run-status')).toContainText('EXECUTION COMPLETE', { timeout: 20000 });
  check('No-WebGL fallback keeps component inspection and calculations usable');
  await fallbackContext.close();
  expect(errors).toEqual([]);
  await writeFile('test-artifacts/browser-results.json', JSON.stringify({ passed: checks.length, checks, pageErrors: errors, webgl }, null, 2));
  console.log(`Browser validation complete: ${checks.length} checks, no page errors.`);
} catch (error) {
  await page.screenshot({ path: 'test-artifacts/failure.png', fullPage: true }).catch(() => {});
  await writeFile('test-artifacts/failure.json', JSON.stringify({ message: error.message, pageErrors: errors, body: await page.locator('body').innerText() }, null, 2));
  throw error;
} finally {
  await browser.close();
}
